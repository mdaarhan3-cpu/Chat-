// PrivateChat relay server — zero dependencies. Run: node server.js
// Server only relays ENCRYPTED payloads. It never sees message text or room keys.
'use strict';
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8080;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SECRET_FILE = path.join(DATA_DIR, 'secret.key');
const MAX_PAYLOAD = 1024 * 1024;            // 1 MB per frame
const HISTORY_PER_ROOM = 100;               // recent encrypted msgs kept in RAM
const ROOM_TTL_MS = 7 * 24 * 3600 * 1000;   // empty rooms expire after 7 days
const MAX_MEMBERS = 10;

fs.mkdirSync(DATA_DIR, { recursive: true });
let users = {};
try { users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); } catch (_) {}
let SECRET;
try { SECRET = fs.readFileSync(SECRET_FILE); } catch (_) { SECRET = crypto.randomBytes(32); fs.writeFileSync(SECRET_FILE, SECRET); }
const saveUsers = () => fs.writeFile(USERS_FILE, JSON.stringify(users), () => {});

// ---------- auth helpers ----------
const hashPass = (pass, salt) => crypto.scryptSync(pass, salt, 32).toString('hex');
function makeToken(user) {
  const exp = Date.now() + 30 * 24 * 3600 * 1000;
  const body = Buffer.from(JSON.stringify({ u: user, e: exp })).toString('base64url');
  const sig = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  return body + '.' + sig;
}
function checkToken(tok) {
  if (typeof tok !== 'string') return null;
  const [body, sig] = tok.split('.');
  if (!body || !sig) return null;
  const good = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.e > Date.now() && users[p.u] ? p.u : null; } catch (_) { return null; }
}
const fails = new Map(); // ip -> {n, until}
function tooMany(ip) { const f = fails.get(ip); return f && f.until > Date.now() && f.n >= 8; }
function noteFail(ip) { const f = fails.get(ip) || { n: 0, until: 0 }; f.n++; f.until = Date.now() + 10 * 60 * 1000; fails.set(ip, f); }

// ---------- rooms ----------
const rooms = new Map(); // id -> {id, members:Set<client>, names:Set<string>, history:[], last:number}
const newRoomId = () => crypto.randomBytes(6).toString('hex').toUpperCase(); // 12 hex chars
function getRoom(id) { return rooms.get(id); }
function presence(room) {
  const online = new Set([...room.members].map(c => c.user));
  const list = [...room.names].map(u => ({ u, on: online.has(u) }));
  for (const c of room.members) send(c, { t: 'presence', room: room.id, members: list });
}
function broadcast(room, obj, except) { for (const c of room.members) if (c !== except) send(c, obj); }
setInterval(() => { const now = Date.now(); for (const [id, r] of rooms) if (!r.members.size && now - r.last > ROOM_TTL_MS) rooms.delete(id); }, 3600 * 1000).unref();

// ---------- minimal WebSocket (RFC 6455) ----------
const server = http.createServer((req, res) => {
  if (req.url === '/health') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end('PrivateChat server running');
});
function send(c, obj) {
  if (c.dead) return;
  const data = Buffer.from(JSON.stringify(obj));
  let head;
  if (data.length < 126) head = Buffer.from([0x81, data.length]);
  else if (data.length < 65536) { head = Buffer.alloc(4); head[0] = 0x81; head[1] = 126; head.writeUInt16BE(data.length, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x81; head[1] = 127; head.writeBigUInt64BE(BigInt(data.length), 2); }
  try { c.socket.write(Buffer.concat([head, data])); } catch (_) {}
}
function sendRaw(c, op, payload = Buffer.alloc(0)) { try { c.socket.write(Buffer.concat([Buffer.from([0x80 | op, payload.length]), payload])); } catch (_) {} }

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  const ip = (req.headers['x-forwarded-for'] || socket.remoteAddress || '').split(',')[0].trim();
  const c = { socket, ip, user: null, rooms: new Set(), dead: false, alive: true, buf: Buffer.alloc(0), frag: null, msgTimes: [] };
  socket.on('data', d => {
    c.buf = Buffer.concat([c.buf, d]);
    try { parse(c); } catch (_) { close(c); }
  });
  socket.on('close', () => close(c));
  socket.on('error', () => close(c));
});

function parse(c) {
  for (;;) {
    const b = c.buf;
    if (b.length < 2) return;
    const fin = !!(b[0] & 0x80), op = b[0] & 0x0f, masked = !!(b[1] & 0x80);
    let len = b[1] & 0x7f, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
    if (!masked || len > MAX_PAYLOAD) return close(c);
    if (b.length < off + 4 + len) return;
    const mask = b.subarray(off, off + 4);
    const payload = Buffer.from(b.subarray(off + 4, off + 4 + len));
    for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
    c.buf = b.subarray(off + 4 + len);
    if (op === 0x8) return close(c);
    if (op === 0x9) { sendRaw(c, 0xA, payload.subarray(0, 125)); continue; }
    if (op === 0xA) { c.alive = true; continue; }
    if (op === 0x1 || op === 0x0) {
      if (op === 0x1) c.frag = [payload]; else if (c.frag) c.frag.push(payload); else continue;
      if (c.frag && c.frag.reduce((n, p) => n + p.length, 0) > MAX_PAYLOAD) return close(c);
      if (fin) { const text = Buffer.concat(c.frag).toString('utf8'); c.frag = null; handle(c, text); }
    }
  }
}
function close(c) {
  if (c.dead) return; c.dead = true;
  try { c.socket.destroy(); } catch (_) {}
  for (const id of c.rooms) { const r = rooms.get(id); if (r) { r.members.delete(c); r.last = Date.now(); presence(r); } }
}
setInterval(() => { for (const c of allClients()) { if (!c.alive) { close(c); continue; } c.alive = false; sendRaw(c, 0x9); } }, 30000).unref();
function* allClients() { const seen = new Set(); for (const r of rooms.values()) for (const c of r.members) if (!seen.has(c)) { seen.add(c); yield c; } }

// ---------- message handling ----------
const NAME_RE = /^[a-z0-9_.]{3,20}$/;
const ROOM_RE = /^[0-9A-F]{12}$/;
function handle(c, text) {
  let m; try { m = JSON.parse(text); } catch (_) { return; }
  if (!m || typeof m.t !== 'string') return;

  if (m.t === 'auth') {
    if (tooMany(c.ip)) return send(c, { t: 'error', code: 'rate', msg: 'Too many attempts. Try again in 10 minutes.' });
    const u = String(m.user || '').trim().toLowerCase(), p = String(m.pass || '');
    if (!NAME_RE.test(u)) return send(c, { t: 'error', code: 'name', msg: 'Username: 3-20 chars, a-z 0-9 _ .' });
    if (p.length < 6 || p.length > 100) return send(c, { t: 'error', code: 'pass', msg: 'Password must be at least 6 characters.' });
    if (m.mode === 'signup') {
      if (users[u]) return send(c, { t: 'error', code: 'exists', msg: 'Username already taken.' });
      const salt = crypto.randomBytes(16).toString('hex');
      users[u] = { salt, hash: hashPass(p, salt), created: Date.now() }; saveUsers();
    } else {
      const rec = users[u];
      const ok = rec && crypto.timingSafeEqual(Buffer.from(hashPass(p, rec.salt)), Buffer.from(rec.hash));
      if (!ok) { noteFail(c.ip); return send(c, { t: 'error', code: 'login', msg: 'Wrong username or password.' }); }
    }
    c.user = u; return send(c, { t: 'auth_ok', user: u, token: makeToken(u) });
  }
  if (m.t === 'resume') {
    const u = checkToken(m.token);
    if (!u) return send(c, { t: 'error', code: 'token', msg: 'Session expired. Please login again.' });
    c.user = u; return send(c, { t: 'auth_ok', user: u, token: m.token });
  }
  if (!c.user) return send(c, { t: 'error', code: 'auth', msg: 'Login first.' });

  // flood control: 30 msgs / 10s
  const now = Date.now(); c.msgTimes = c.msgTimes.filter(t => now - t < 10000); c.msgTimes.push(now);
  if (c.msgTimes.length > 30) return send(c, { t: 'error', code: 'flood', msg: 'Slow down.' });

  if (m.t === 'create') {
    let id; do { id = newRoomId(); } while (rooms.has(id));
    rooms.set(id, { id, members: new Set(), names: new Set(), history: [], last: now });
    return send(c, { t: 'created', room: id });
  }
  if (m.t === 'join') {
    const id = String(m.room || '').toUpperCase();
    if (ROOM_RE.test(id) && !rooms.has(id) && m.recreate === true) // server restarted: let a member who owns the code revive it
      rooms.set(id, { id, members: new Set(), names: new Set(), history: [], last: now });
    const r = ROOM_RE.test(id) && rooms.get(id);
    if (!r) return send(c, { t: 'error', code: 'noroom', room: id, msg: 'Room not found. Check the code.' });
    if (!r.names.has(c.user) && r.names.size >= MAX_MEMBERS) return send(c, { t: 'error', code: 'full', room: id, msg: 'Room is full.' });
    r.names.add(c.user); r.members.add(c); c.rooms.add(id); r.last = now;
    send(c, { t: 'joined', room: id, history: r.history });
    presence(r);
    return;
  }
  const r = rooms.get(String(m.room || '').toUpperCase());
  if (!r || !r.members.has(c)) return;
  if (m.t === 'msg') {
    if (typeof m.c !== 'string' || typeof m.iv !== 'string' || typeof m.id !== 'string' || m.id.length > 40) return;
    const out = { t: 'msg', room: r.id, id: m.id, from: c.user, c: m.c, iv: m.iv, ts: now };
    r.history.push(out); if (r.history.length > HISTORY_PER_ROOM) r.history.shift();
    send(c, { t: 'ack', room: r.id, id: m.id, ts: now });
    broadcast(r, out, c);
  } else if (m.t === 'delivered' || m.t === 'seen') {
    if (typeof m.id !== 'string') return;
    broadcast(r, { t: m.t, room: r.id, id: m.id, by: c.user, to: m.to }, c);
  } else if (m.t === 'typing') {
    broadcast(r, { t: 'typing', room: r.id, from: c.user }, c);
  } else if (m.t === 'leave') {
    r.members.delete(c); c.rooms.delete(r.id);
    if (m.forget) r.names.delete(c.user);
    presence(r);
  }
}

server.listen(PORT, () => console.log('PrivateChat server on port ' + PORT));
