# PrivateChat 2.0

Private, end-to-end encrypted group/1-to-1 chat. Do hisse hain:

- `server/`  – chhota relay server (Node.js, **koi npm install nahi**)
- `android/` – Android Studio project (app)

## Step 1 — Server chalao
**Apne PC par (test):** `cd server && node server.js` (port 8080)
App me address do: `192.168.x.x:8080` (PC ka local IP, dono same WiFi par).

**Internet par (free, Render.com):** GitHub par `server` folder daalo → Render → New Web Service →
Build command khaali, Start command `node server.js`. Milega `https://yourapp.onrender.com`
→ app me sirf `yourapp.onrender.com` likho.
(Free plan 15 min idle ke baad sleep hota hai, pehla connect ~30 sec le sakta hai.)

## Step 2 — App banao
Android Studio → Open → `android` folder → Build → Build APK(s).

## Kaise use kare
1. App kholo → server address → Sign up (username + password).
2. **Naya room** → code milega (`XXXXXXXXXXXX-YYYYYYYYYYYYYYYY`) → Share karo.
3. Dost: **Code se join karo** → code paste.

## Security
- Messages/photos phone par AES-256-GCM se encrypt hote hain; key room code ke 2nd hisse se banti hai
  jo server ko kabhi nahi bheja jata. Server sirf encrypted data relay karta hai.
- Passwords server par scrypt hash me; login token signed; rate-limit aur flood control.
- Screenshots default me blocked (Settings se band kar sakte ho).

## Limits (jaanna zaroori)
- App band hone par push notification nahi aata (iske liye Firebase FCM chahiye).
- Server RAM me sirf last 100 encrypted messages rakhta hai; asli history phone me hoti hai.
- Server restart par rooms apne aap wapas ban jate hain jab koi member connect kare.

## APK bina Android Studio ke (sirf phone/browser se)
1. github.com par naya repo banao, is folder ka **poora content** upload karo (`.github` folder ke saath).
2. Repo → **Actions** tab → "Build APK" → Run workflow (push par apne aap bhi chalta hai).
3. 3-5 minute baad run kholo → neeche **Artifacts → PrivateChat-APK** download karo → zip kholo → `app-debug.apk` install karo.
